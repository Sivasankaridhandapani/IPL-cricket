import pandas as pd

from src.data_cleaning import clean_matches, clean_deliveries
from src.feature_engineering import encode_features
from src.models import train_models
from src.analysis import (
    winner_by_season,
    super_over_analysis,
    high_scoring_matches,
    orange_purple_caps
)
from src.visualization import team_wins_bar

# Load data
matches = pd.read_csv("data/matches.csv")
deliveries = pd.read_csv("data/deliveries.csv")

# Clean data
matches = clean_matches(matches)
deliveries = clean_deliveries(deliveries)

# Feature engineering
matches, le_team, le_winner = encode_features(matches)

# Analysis
print("Winner by Season:")
print(winner_by_season(matches))

print("Super Over Match Count:", super_over_analysis(matches))
print("High Scoring Matches:", high_scoring_matches(matches).shape[0])

orange, purple = orange_purple_caps(deliveries)
print("Orange Cap:", orange)
print("Purple Cap:", purple)

# Visualization
team_wins_bar(matches)

# Train & predict
model = train_models(matches)

# Example prediction
team1 = "Mumbai Indians"
team2 = "Chennai Super Kings"

t1 = le_team.transform([team1])[0]
t2 = le_team.transform([team2])[0]

pred = model.predict([[t1, t2, t1, 0]])
print("Predicted Winner:", le_winner.inverse_transform(pred)[0])
