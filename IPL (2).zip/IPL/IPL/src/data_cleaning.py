import pandas as pd

def clean_matches(matches):
    matches = matches.dropna(subset=['team1', 'team2'])
    matches['winner'] = matches['winner'].fillna('No Result')
    matches['toss_decision'] = matches['toss_decision'].fillna('bat')
    return matches

def clean_deliveries(deliveries):
    deliveries['is_wicket'] = deliveries['is_wicket'].fillna(0)
    deliveries['batsman_runs'] = deliveries['batsman_runs'].fillna(0)
    return deliveries
