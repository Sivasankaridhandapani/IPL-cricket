def winner_by_season(matches):
    return matches.groupby('season')['winner'].agg(
        lambda x: x.value_counts().index[0]
    )

def super_over_analysis(matches):
    return matches[matches['super_over'] == 1].shape[0]

def high_scoring_matches(matches):
    return matches[matches['target_runs'] >= 200]

def orange_purple_caps(deliveries):
    orange = deliveries.groupby('batter')['batsman_runs'].sum().idxmax()
    purple = deliveries.groupby('bowler')['is_wicket'].sum().idxmax()
    return orange, purple
