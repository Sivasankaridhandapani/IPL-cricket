import matplotlib.pyplot as plt
import seaborn as sns

def team_wins_bar(matches):
    wins = matches['winner'].value_counts().head(10)
    sns.barplot(x=wins.values, y=wins.index)
    plt.title("Top 10 IPL Teams by Wins")
    plt.xlabel("Wins")
    plt.ylabel("Team")
    plt.show()
