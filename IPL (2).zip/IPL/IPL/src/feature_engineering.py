from sklearn.preprocessing import LabelEncoder

def encode_features(matches):
    le_team = LabelEncoder()
    le_winner = LabelEncoder()

    matches['team1_enc'] = le_team.fit_transform(matches['team1'])
    matches['team2_enc'] = le_team.transform(matches['team2'])
    matches['winner_enc'] = le_winner.fit_transform(matches['winner'])

    matches['toss_winner_enc'] = le_team.transform(matches['toss_winner'])
    matches['toss_decision_enc'] = matches['toss_decision'].map(
        {'bat': 0, 'field': 1}
    )

    return matches, le_team, le_winner
