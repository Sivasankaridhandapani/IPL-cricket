IPL Cricket Analysis and Prediction System

This project analyses IPL data and predicts match winners using
machine learning techniques.

Features:
- Match winner prediction
- Super over analysis
- High scoring match analysis
- Orange & Purple cap winners
- Visual insights using graphs

Model Used:
- Random Forest Classifier

Tools:
Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn
